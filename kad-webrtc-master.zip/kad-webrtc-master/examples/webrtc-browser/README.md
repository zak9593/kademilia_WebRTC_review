webrtc-browser
====================

This example demonstrates using the WebRTC transport in the browser.

For simplicity's sake a signal server is omitted.
To see an end-to-end example with a signal server,
check out the `webrtc-browser-e2e` example.

## Running the example

Start a static server, for example with
[http-server](https://github.com/indexzero/http-server):

    http-server -c-1

Then, in your browser navigate to

    http://localhost:8080/examples/webrtc-browser/index.html
