/**
 * @module kad-webrtc
 */

'use strict';

module.exports = require('./lib/transport');
module.exports.Contact = require('./lib/contact');
